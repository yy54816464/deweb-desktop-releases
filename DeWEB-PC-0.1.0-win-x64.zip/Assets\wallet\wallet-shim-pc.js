/* PoC Windows shim: same contract as Android wallet-shim.js, backed by
   WebView2 chrome.webview instead of Android's WebMessageListener. */
(function () {
  'use strict';
  if (window.top !== window) return;
  window.__dewebKeepWalletCache = true;
  window.__dewebAndroidWallet = true;
  if (window.__dewebWalletShimInstalled) return;
  window.__dewebWalletShimInstalled = true;

  function post(obj) {
    try {
      var s = JSON.stringify(obj || {});
      if (window.chrome && chrome.webview) chrome.webview.postMessage(s);
      else console.log('no webview bridge', s);
    } catch (e) {}
  }

  try {
    if (window.chrome && chrome.webview) {
      chrome.webview.addEventListener('message', function (ev) {
        var msg = ev.data;
        if (typeof msg === 'string') { try { msg = JSON.parse(msg); } catch (e) { return; } }
        if (!msg || !msg.__walletNative) return;
        try {
          if (msg.payload && msg.payload.type === 'poc') {
            post({ type: 'poc', ok: true, message: msg.payload.message || '' });
            return;
          }
          if (window.__dewebWalletHandler) window.__dewebWalletHandler(msg.payload || {});
        } catch (e) { post({ type: 'error', message: String(e && e.message || e) }); }
      });
    }
  } catch (e) {}

  var nativeOpen = window.open;
  window.open = function (url) {
    try {
      var u = String(url || '');
      if (/^(okx|okxwallet|okxweb3):/i.test(u) ||
          /^https?:\/\/(web3link\.okx\.com|link\.okx\.com|web3\.okx\.com\/ul\/connect)/i.test(u)) {
        post({ type: 'open_url', url: u });
        return null;
      }
    } catch (e) {}
    return nativeOpen ? nativeOpen.apply(window, arguments) : null;
  };

  window.dewebShell = {
    isElectron: true,
    onWalletRequest: function (handler) { window.__dewebWalletHandler = handler; },
    sendWalletResponse: function (res) { post(res || {}); },
    walletAccountsChanged: function (accounts) { post({ type: 'accounts', accounts: accounts || [] }); },
    walletChainChanged: function (chainId) { post({ type: 'chain', chainId: chainId }); },
    focusWallet: function () { post({ type: 'focus' }); },
    debug: function (message) { post({ type: 'debug', message: String(message || '') }); },
    membershipChanged: function () { post({ type: 'membership_changed' }); },
    rpc: function () { return Promise.resolve(null); }
  };

  window.__dewebWalletRequest = function (req) {
    try {
      if (window.__dewebWalletHandler) window.__dewebWalletHandler(req);
      else post({ type: 'error', message: 'wallet handler not ready' });
    } catch (e) { post({ type: 'error', message: String(e && e.message || e) }); }
  };
})();
