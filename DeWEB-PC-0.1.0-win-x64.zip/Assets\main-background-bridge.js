/* Main DeWEB desktop background: only the native openSite hook. */
(function () {
  'use strict';
  if (window.top !== window) return;
  if (!window.dewebBridge) return;
  window.dewebNative = {
    isNative: true,
    isDesktop: true,
    openSite: function (url, chain) {
      try {
        window.dewebBridge.postMessage(JSON.stringify({
          id: 'bg-open-' + Date.now(),
          method: 'deweb_open_site',
          params: [String(url || ''), String(chain || 'web')]
        }));
      } catch (e) {}
    }
  };

  function postNative(method) {
    try {
      window.dewebBridge.postMessage(JSON.stringify({
        id: 'ui-' + Date.now(),
        method: method,
        bridgeVersion: 1
      }));
    } catch (e) {}
  }

  // Native-only actions live in the page's existing bottom tray, not in the
  // Windows title strip. This keeps the page as the single action surface.
  function installDesktopActions() {
    var tray = document.querySelector('.dtray');
    if (!tray) return;
    // The native strip already carries the brand; hide the page's decorative
    // duplicate header while keeping .top and its real controls.
    if (!document.getElementById('deweb-native-chrome')) {
      var brandStyle = document.createElement('style');
      brandStyle.id = 'deweb-native-chrome';
      brandStyle.textContent = '#desktop .dhead{display:none!important}';
      (document.head || document.documentElement).appendChild(brandStyle);
    }
    if (document.getElementById('deskSettings')) return;
    var settings = document.createElement('button');
    settings.className = 'dtrayb';
    settings.id = 'deskSettings';
    settings.title = '设置与诊断';
    settings.textContent = '设置';
    settings.onclick = function (e) {
      try { e.preventDefault(); e.stopPropagation(); } catch (x) {}
      postNative('deweb_open_settings');
    };
    var disconnect = document.createElement('button');
    disconnect.className = 'dtrayb';
    disconnect.id = 'deskDisconnectAll';
    disconnect.title = '断开全部钱包';
    disconnect.textContent = '断开全部';
    disconnect.style.color = 'var(--err, #ff8d70)';
    disconnect.onclick = function (e) {
      try { e.preventDefault(); e.stopPropagation(); } catch (x) {}
      postNative('deweb_disconnect_all');
    };
    var before = document.getElementById('deskMountBtn');
    tray.insertBefore(settings, before || null);
    tray.insertBefore(disconnect, before || null);
  }

  try {
    document.addEventListener('DOMContentLoaded', installDesktopActions, { once: true });
  } catch (e) {}
  try {
    var tries = 0;
    var timer = setInterval(function () {
      installDesktopActions();
      if (document.getElementById('deskSettings') || ++tries > 240) clearInterval(timer);
    }, 500);
  } catch (e) {}
})();
