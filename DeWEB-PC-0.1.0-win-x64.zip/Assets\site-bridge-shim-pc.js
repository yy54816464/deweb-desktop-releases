/* PC site-window shim: backs Android's injected dewebBridge object with
   WebView2 chrome.webview. The wallet provider itself is installed only in the
   top frame by site-bridge.js. */
(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__dewebSiteShim) return;
  window.__dewebSiteShim = true;

  window.dewebBridge = {
    onmessage: null,
    postMessage: function (raw) {
      try {
        if (window.chrome && chrome.webview)
          chrome.webview.postMessage(String(raw));
      } catch (e) {}
    }
  };

  try {
    if (window.chrome && chrome.webview) {
      chrome.webview.addEventListener('message', function (ev) {
        var data = ev.data;
        if (typeof data !== 'string') data = JSON.stringify(data);
        try {
          if (window.dewebBridge.onmessage)
            window.dewebBridge.onmessage({ data: data });
        } catch (e) {}
      });
    }
  } catch (e) {}
})();
