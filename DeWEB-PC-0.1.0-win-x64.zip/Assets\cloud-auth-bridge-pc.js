/* PC main-container cloud auth bridge. Top frame only; messages are validated
   again natively (origin, id length, method, and sign-message format). */
(function () {
  try {
    if (window.top !== window) return;
    if (window.__dewebCloudAuthShim) return;
    window.__dewebCloudAuthShim = true;

    function send(method, id, message) {
      try {
        var payload = { id: String(id || ''), method: String(method || '') };
        if (method === 'sign') payload.message = String(message || '');
        if (window.chrome && chrome.webview)
          chrome.webview.postMessage(JSON.stringify(payload));
      } catch (e) {}
    }

    window.dewebCloudAuth = {
      connect: function (id) { send('connect', id); },
      sign: function (id, message) { send('sign', id, message); },
      disconnect: function (id) { send('disconnect', id); }
    };
  } catch (e) {}
})();
